import { Suspense } from "react";
import { PostView } from "@/components/post-view";
export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return (
    <Suspense fallback={<p role="status">Жүктелуде...</p>}>
      <PostView id={id} />
    </Suspense>
  );
}
