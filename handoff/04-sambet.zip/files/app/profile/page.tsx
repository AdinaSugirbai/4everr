import { Heading, Notice, ButtonLink } from "@/components/ui";
export default function Page() {
  return (
    <>
      <Heading
        label="Жеке кабинет"
        title="Сенің дамуың — бір жерде."
        description="Нәтижелер, оқу жолы және жұмысқа алғашқы қадамдар."
      />
      <Notice>
        Бұл — интерфейс нұсқасы. Кіру мен тіркелу, рөлдерді тексеру және
        дерекқор келесі серверлік кезеңге жатады.
      </Notice>
      <div className="grid md:grid-cols-3 gap-4">
        {[
          [
            "Менің нәтижелерім",
            "Осы браузердегі демо тесттер тарихы.",
            "/stats",
            "Статистика",
          ],
          [
            "Менің өтінімдерім",
            "Нақты өтінімдер үшін кандидат аккаунты қажет.",
            "/jobs",
            "Вакансиялар",
          ],
          [
            "Оқу жолым",
            "Өз бағытыңды таңдап, оқу қадамдарын зертте.",
            "/careers",
            "Мамандықтар",
          ],
        ].map(([t, d, url, cta]) => (
          <article className="card" key={t}>
            <h2 className="text-2xl">{t}</h2>
            <p className="my-5 text-sm">{d}</p>
            <ButtonLink href={url}>{cta}</ButtonLink>
          </article>
        ))}
      </div>
    </>
  );
}
