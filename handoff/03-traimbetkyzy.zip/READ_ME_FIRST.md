# 3. Траймбетқызы А.

Бұл ZIP — ортақ дайын сайттың тек сізге тиесілі бөлігі. Толық жобаны жалғыз өзіңіз жүктемеңіз.

Тармақ: `feature/dashboard-jobs`.

## Алғаш рет репозиторийді алу

Егер компьютерде әлі жоқ болса:

```bash
git clone https://github.com/AdinaSugirbai/4everr.git
cd 4everr
code .
```

Бұрын толық UI тармағы `dev`-ке merge жасалмағанына көз жеткізіңіз.

## Реті

Алдымен 2-бөліктің PR-ы `dev`-ке біріктірілсін. Содан кейін жаңартылған `dev`-тен өз тармағыңызды ашыңыз.

```bash
git fetch origin
git switch dev
git pull --ff-only origin dev
git switch -c feature/dashboard-jobs
```

Осы ZIP ішіндегі **files/** папкасының ішін репозиторий түбіріне көшіріңіз. `files` папкасының өзін көшірмеңіз. `READ_ME_FIRST.md` пен `FILES.txt` — нұсқаулық, оларды жобаға салмаңыз.

```bash
npm ci
npm run lint
npm run typecheck
npm run build
git status
git add .
git commit -m "feat: add dashboard history and vacancy UI"
git push -u origin feature/dashboard-jobs
```

`git add .` алдында тек `FILES.txt` ішіндегі файлдар өзгергенін тексеріңіз. Өзге жеке файлдар не құпия кілт болса, оларды stage етпеңіз. VS Code Source Control арқылы нақты файлдарды таңдап stage етуге болады.

GitHub-та **base: dev**, compare: өз тармағыңыз болатын PR ашыңыз. Кемінде бір командалас қарап бекітсін. Осы бөлік `dev`-ке біріктірілгеннен кейін келесі қатысушы бастайды.

Commit-ті өз GitHub аккаунтыңызбен жасаңыз. Commit email-і сол аккаунтқа байланыстырылсын. Өзгенің атын/почтасын қоймаңыз.

Бұл кезеңде келесі қатысушылардың беттері әлі қосылмаған болуы қалыпты. Толық сайт төрт бөлік біріктірілген соң дайын болады.
