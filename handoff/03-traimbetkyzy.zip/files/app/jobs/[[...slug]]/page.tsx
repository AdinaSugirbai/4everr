import Link from "next/link";
import { Suspense } from "react";
import { notFound } from "next/navigation";
import { Heading, Notice, Chips, ButtonLink } from "@/components/ui";
import { JobList, ApplyButton } from "@/components/jobs";
import { jobs, formats } from "@/lib/data";
export default async function Page({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const { slug = [] } = await params;
  if (slug.length > 1) notFound();
  const id = slug[0];
  const section = "jobs";
  if (section === "jobs" && !id)
    return (
      <>
        <Heading
          label="Job Board"
          title="Келесі қадамың — осында."
          description="Жұмыс пен тағылымдама мүмкіндіктерін өз бағытыңа сай ізде."
        />
        <Notice>
          Барлық вакансиялар, компаниялар мен жалақылар — интерфейсті көрсетуге
          арналған ойдан шығарылған деректер.
        </Notice>
        <Suspense fallback={<p role="status">Вакансиялар жүктелуде...</p>}>
          <JobList />
        </Suspense>
      </>
    );
  if (section === "jobs" && id) {
    const j = jobs.find((j) => j.id === id);
    if (!j) notFound();
    return (
      <>
        <Link
          className="inline-flex min-h-11 items-center text-sm mt-6"
          href="/jobs"
        >
          ← Вакансиялар
        </Link>
        <Heading
          label="Демо-вакансия"
          title={j.title}
          description={`${j.company} · ${j.city} · ${formats[j.format]}`}
        />
        <div className="grid lg:grid-cols-[1.8fr_1fr] gap-5">
          <article className="card">
            <h2>Жұмыс туралы</h2>
            <p className="my-5">
              Оқу жобаларында алған біліміңді командадағы міндеттерге қолдан.
              Тәлімгермен бірге өнімді дамытуға қатыс.
            </p>
            <h3 className="text-lg mb-4">Қажетті дағдылар</h3>
            <Chips items={j.skills} />
            <h3 className="text-lg mt-7 mb-3">Міндеттер</h3>
            <p>
              Командалық тапсырмаларды орындау, кодты тексеруге қатысу және жаңа
              дағдыларды меңгеру.
            </p>
            <div className="flex flex-wrap gap-3 mt-6">
              <ButtonLink href="/tests">Дағдыларымды тексеру</ButtonLink>
              <ButtonLink href={"/careers/" + j.career}>
                Бағытпен танысу
              </ButtonLink>
            </div>
          </article>
          <aside className="card self-start">
            <h2 className="text-2xl">{j.salary}</h2>
            <p className="my-5">Айына · {j.level} · демо</p>
            <ApplyButton />
            <Notice>
              Алдын ала төлем сұраған жұмыс берушіден сақ болыңыз.
            </Notice>
          </aside>
        </div>
      </>
    );
  }

  notFound();
}
