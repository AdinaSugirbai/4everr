import Link from "next/link";
import { notFound } from "next/navigation";
import { Heading } from "@/components/ui";
import { EmployerForm } from "@/components/jobs";
export default async function Page({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const { slug = [] } = await params;
  if (slug.length > 1) notFound();
  const id = slug[0];
  const section = "employer";
  if (section === "employer") {
    if (id === "new")
      return (
        <>
          <Heading
            label="Вакансия жобасы"
            title="Командаңа кімді іздеп жүрсің?"
            description="UI үлгісі: деректер серверге жіберілмейді және жарияланбайды."
          />
          <EmployerForm />
        </>
      );
    if (id) notFound();
    return (
      <>
        <Heading
          label="Жұмыс берушілерге"
          title="Жаңа таланттармен таныс."
          description="Вакансия жариялау мен өтінімдерді басқару — бір жерде."
        />
        <div className="grid md:grid-cols-3 gap-4">
          {[
            [
              "01",
              "Компания профилі",
              "Компанияң туралы ақпарат пен жұмыс форматын көрсет.",
            ],
            [
              "02",
              "Вакансия жасау",
              "Бағыт, қажетті дағдылар мен жұмыс шарттарын таңда.",
            ],
            [
              "03",
              "Өтінімдерді басқару",
              "Модерациядан кейін үміткерлердің өтінімдерін қара.",
            ],
          ].map(([n, t, d]) => (
            <article className="card" key={n}>
              <span className="eyebrow">{n}</span>
              <h3 className="text-2xl mt-6 mb-3">{t}</h3>
              <p className="text-sm">{d}</p>
            </article>
          ))}
        </div>
        <div className="band">
          <div>
            <h2 className="text-2xl mb-2">Вакансияңды дайында.</h2>
            <p>Демо форма ештеңе жарияламайды және деректерді сақтамайды.</p>
          </div>
          <Link href="/employer/new" className="btn btn-light">
            Демо форманы ашу →
          </Link>
        </div>
      </>
    );
  }

  notFound();
}
