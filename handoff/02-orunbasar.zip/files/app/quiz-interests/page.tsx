import { InterestQuiz } from "@/components/interest-quiz";
export default function Page() {
  return <InterestQuiz />;
}
