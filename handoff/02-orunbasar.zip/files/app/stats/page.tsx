import { Heading } from "@/components/ui";
import { Stats } from "@/components/tech-test";
export default function Page() {
  return (
    <>
      <Heading
        label="Жеке статистика"
        title="Прогресіңді көр. Өзіңді дамыт."
        description="Осы браузердегі демо-тест нәтижелері. Деректер серверге жіберілмейді."
      />
      <Stats />
    </>
  );
}
