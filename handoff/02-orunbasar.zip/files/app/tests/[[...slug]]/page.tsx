import { notFound } from "next/navigation";
import { Heading } from "@/components/ui";
import { TestList, TechTest } from "@/components/tech-test";
import { topics } from "@/lib/data";
export default async function Page({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const { slug = [] } = await params;
  if (slug.length > 1) notFound();
  const id = slug[0];
  const section = "tests";
  if (section === "tests") {
    if (!id)
      return (
        <>
          <Heading
            label="TechTest"
            title="Біліміңді тексер. Келесі қадамды біл."
            description="Тақырыпты таңда, тапсырмаларды орында және қай дағдыны дамыту керегін анықта."
          />
          <TestList />
        </>
      );
    const topic = topics.find((t) => t.toLowerCase() === id);
    if (!topic) notFound();
    return <TechTest key={topic} topic={topic} />;
  }

  notFound();
}
